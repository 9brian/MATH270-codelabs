
# Solve System of equations with gaussian elimination algorithm
# Your name:  Brian Palomar

import numpy as np

# Complete rref
# Complete rank
"""When M is in RREF form, if the rank(M) 
equals the number of variables, then there 
is a single solution and that solution is 
the last column of M."""


def swap(M, i, j): # exchange rows i and j in matrix M
    if i==j:
        return # Return
    else:
        Trow = M[i,].copy() # Make a copy of row i
        M[i,]=M[j,] # Replace row i with row j
        M[j,]=Trow # replace Trow with row j


def mult(M, i, a): # multiply row i by the number a
    M[i,]=a*M[i,]


def er3(M, i, a, j): # multiple row i by number a and add to row j and replace row j
    #  a*r(i) + r(j) -> r(j)
    M[j,]=a*M[i,]+M[j,]

def findNZEntry(M, top):
    # find non zero entry starting at row top, search column by column.
    mrows, mcols = M.shape # give values to row/col of matrix
    for icol in range(mcols): # col by col
            for irow in range(top,mrows): # row by row
                    if (M[irow,icol]!=0 ): # finds non zero
                            return (irow, icol) # return the row/col
    return (-1,-1) # matrix is all zeros

def rref(M):
    # input - matrix m augmented matrix for system of equations
    # return - matrix m in reduced row echelon form

    mrows, mcols = M.shape # iterators row/cl
    for top in range(mrows): # for loop in range of len of rows
        arow, acol = findNZEntry(M, top)
        # print(arow, acol, "yo") #displays ones
        
        if arow==-1:
                return M
        else:
                swap(M, top, arow)
                mult(M, top, 1.0/M[top,acol]) # make the leading entry a 1
                # make everything below leading 1 a zero
                for irow in range(top+1,mrows):
                        er3(M, top, -M[irow,acol], irow)
                # make everything above the leading 1 a zero
                for irow in range(top):
                        er3(M, top, -M[irow,acol], irow)     
    return M
        
def rank(M):
    # input - matrix m is augmented matrix in reduced row echeclon format
    # return - rank of matrix m
    #       if M is inconsistent, then return 0
    #       M is inconcsistent if there is a row that has a leading 1 in the
    #         last column
    nrows, ncols  = M.shape
    rank = 0
    for top in range(nrows): # for loop in range of # of rows
        arow, acol = findNZEntry(M, top)
        # print(arow, acol, (nrows-1), (ncols-1))
        
        # print(arow, acol, "top= ", top)
        if (arow, acol) == (nrows-1, ncols-1): # inconsistent if
            # If findNZEntry is the last column meaning 0x+0y+0z=(non-zero)
            rank = 0
        elif ((arow, acol) != (-1, -1)):
            rank += 1 # counter for how many times for loop has looped

    return rank
           

print("\nTest 1- 2 variables, 2 equations, 1 solution.")
M = np.matrix('3. 4. 5.; 1. 2. 3.'); #Make matric
R = M.copy() # save a copy of M
mrows, mcols = M.shape # Shape of matrix
print(M) # Print shape 
M = rref(M) # Call rref
print("Row echelon form") # Print statement
print(M) # New matrix
r = rank(M) # Call rank 
print('rank =', r) # Print statement
# answer is in last column of M
# verify answer by doing R[coefficients] X M[last column] == R[constants]
print("verify answer") # Verified answer
print (np.matmul(R[:,0:mcols-1], M[:,mcols-1]))
print("expected answer") # Expected Answer
print(R[:,mcols-1])


print("\nTest 2 - 3 variables, 3 equations, one solution.")
M = np.matrix([[1., 1., 1., 5.],[1., -1., 2., 11.],[1., -1., -2., -5.]])
# save a copy of M
R = M.copy()
mrows, mcols = M.shape
print(M)
M = rref(M)
print("Row echelon form")
print(M)
r = rank(M)
print('rank =', r)
# answer is in last column of M
# verify answer by doing R[coefficients] X M[last column] == R[constants]
print("verify answer")
print (np.matmul(R[:,0:mcols-1], M[:,mcols-1]))
print("expected answer")
print(R[:,mcols-1])


print("\nTest 3 - 6 variables, 3 equations, multiple solutions.")
M = np.matrix('0. -1. 3. 1. 3. 2. 1.; 0. -2. 6. 1. -5. 0. -1.; 0. 3. -9. 2. 4. 1. -1.; 0. 1. -3. -1. 3. 0. 1.')
# save a copy of M
R = M.copy()
mrows, mcols = M.shape
print(M)
M = rref(M)
print("Row echelon form")
print(M)
r = rank(M)
print('rank =', r)
print('the rank is less than number of variables', mcols-1, ' so there are many solutions.')


print("\nTest 4 - 3 variables, 3 equations, inconsistent. No solution.")
M = np.matrix([[1., 1., 1., 5.],[1., -1., 2., 11.],[2.0, 0.0, 3.0, 15.0]])
# save a copy of M
R = M.copy()
mrows, mcols = M.shape
print(M)
M = rref(M)
print("Row echelon form")
print(M)
r = rank(M)
print('rank =', r)
print('the rank is 0, so the equations are inconsistent.')



print("\nTest 5- 3 variables, 3 equations, 1 solution.")
M = np.matrix([[1., 1., -1., 5.],[0., 1., -5., 8.],[0., 0., 1., -1.]])
R = M.copy() # save a copy of M
mrows, mcols = M.shape # Shape of matrix
print(M) # Print shape 
M = rref(M) # Call rref
print("Row echelon form") # Print statement
print(M) # New matrix
r = rank(M) # Call rank 
print('rank =', r) # Print statement
# answer is in last column of M
# verify answer by doing R[coefficients] X M[last column] == R[constants]
print("verify answer") # Verified answer
print (np.matmul(R[:,0:mcols-1], M[:,mcols-1]))
print("expected answer") # Expected Answer
print(R[:,mcols-1])


print("\nTest 6 - 3 variables, 3 equations, multiple solutions.")
M = np.matrix([[0., 2., 1., 1.],[0., -4., 2., 3.],[0., 0., 0., 0.]])
# save a copy of M
R = M.copy()
mrows, mcols = M.shape
print(M)
M = rref(M)
print("Row echelon form")
print(M)
r = rank(M)
print('rank =', r)
print('the rank is less than number of variables', mcols-1, ' so there are many solutions.')
# print(M.item(2, 3))