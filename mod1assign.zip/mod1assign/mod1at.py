## Math270 Mod 1 Assignment
## Brian Palomar
import math
from math import modf
import random
import matplotlib.pyplot as plt

# Part 1
footwear = ["sneakers", "crocs", "running shoes", 
            "bowling shoes", "skating shoes",
            "sandals"] # List of choices of footwear
shoe_color = ["red", "blue", "pink", "yellow", "gray", 
                "purple", "black", "white", "green"]
                # List of different 

def rounder(x): # Rounds to the nearest 10's place
    return round((x * 2) / 2)

list_sizes = [] # Empty list to store all sizes

def random_shoe(shoe_color, shoe_type): # Picks random shoe attributes
    shoe_size = random.uniform(6, 16) # random shoe size between 6 and 14 (decimals included)
    format_shoe = float("{:.2f}".format(shoe_size)) # Sets two nums after decimal
    rand_size =rounder(format_shoe) # Calls rounder to round

    color = random.randint(0, len(shoe_color)-1) # Picks color based on colors given
    shoes = random.randint(0, len(shoe_type)-1) # Picks a tyep of shoe based on types given
    list_sizes.append(rand_size) # Adds to the list of sizes
    
    return shoe_color[color], shoe_type[shoes], rand_size # returns shoe color, type, size

def avg(values): # avg function
       return rounder(sum(values) / len(values))

def std(values): #standard dev function
    mean = avg(values) # Mean of the values
    x_i = 0 # Holder for total
    for value in values: # Iterates through every value in list
        # Subtracts value[i] by mean, then squares it to find variance
            # before divided by n
        x_i += math.pow((value-mean),2) 
    
    # Finds standard deviation
    result = math.sqrt( x_i / len(values) )
    return result # returns result

def part1(ax):
    ls = [] # Empty shoe list
    for i in range(1000): # Runs shoe picker 100 times
        shoe = random_shoe(shoe_color, footwear) # Calls function
        ls.append(shoe) # appends shoe & attributes to empty list

    # Print onto terminal
    for value in ls: # Loops through each value in ls
        counter = 0 # Initalizes counter
        for i in value: # For every element in the value
            counter += 1 # Increments counter
            if counter <= 2: # Prints elements spaced out
                print(i, end=" ")
            else: # Moves onto the next line
                print(i)

    hist(ax, list_sizes, x_label="Men's Shoe Size Distribution", y_label='Probability Density',
     density=True, bin_w=1, bin_start=0.0,
     title='Shoe Size avg= %.1f-%.1f std= %.2f'%(avg(list_sizes), (avg(list_sizes) + .5), std(list_sizes)))

    print()
    # print("Avg=", avg(list_sizes), "Std=%.2f",std(list_sizes))
    print("# of size 10's=", list_sizes.count(10), ",   # of size 14's=", list_sizes.count(14))

# Part 2 (Extra Credit)
def hist(ax, values, x_label, 
            title='', y_label='Frequency', 
            density=False,
            bin_w=0, bin_start=0.0
            ):
    #start with last week's histogram function,
    #and add in the required binning parameters
    
    if bin_w > 0: # If bin values exist
        m = 0 # I&D max val
        for value in values: # For loop that updates max value
            if value > m:
                m = value # Max val updater

        x_axis = [0]*(int((m-bin_start)/bin_w)+1) # Creates x_axis
        for i in range(len(x_axis)): # Creates x_axis values
            x_axis[i] = (bin_start + i*bin_w)

            
        # nob = math.ceil( abs( ((m - bin_start) / bin_w ) + 1) ) # Creates number of bins
        nob = len(x_axis)# creates number of bins
       
        h = [0] * (nob) # initializes frequency table
        for value in values: # for loop to update frequency table
            h[int(value//bin_w)] += 1

        if density==True: # Gate to allow rf
            for index, frequency in enumerate(h): # iterate through frequency table
                h[index] = frequency / len(values) # Gives rf

        ax.bar(x_axis, h, width=bin_w, align='edge')
        ax.set_ylabel(y_label)  # the x and y axis labels and title
        ax.set_xlabel(x_label)
        if len(title) > 0:
            ax.set_title(title) # Sets table title

if __name__ == "__main__":
    # Makes the 2x2 bar graphs
    fig, axes = plt.subplots(2,2, figsize=(10,5))
    plt.subplots_adjust(hspace=0.5) # Space between graphs

    part1(axes[0,0]) # Graph for part 1
    # part2(axes[0,1]) # Graphs for part 2

    plt.show() # show graphs



# Make sure you label each of histograms.

# Submit 2 files
# your python file  .py 
# your PDF file. 

# """