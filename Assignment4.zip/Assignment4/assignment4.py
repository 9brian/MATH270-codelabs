# ## Math270 Assignment 4
# ## Brian Palomar-Salazar
import matplotlib.pyplot as plt
import random
# # hist - make and display a frequency histogram
# #        values - a list of integer values
# #        density - False the y axis is frequency count
# #                  True y axis is relative frequency
# #        return - None

# #start with last week's histogram function,
#          #and add in the required density parameter
def hist(ax, values, x_label, title='', y_label='Frequency', density=False):
    # print() # Spacer
    m = 12 # Initializes & declares

    m = 0 # Initializes & declares
    # For loop that updates max value
    for value in values:
        if value > m:
            m = value
    # print(m) # print max value

    h = [0] * (m+1) # Makes a list of 0's, acting as starting frequency table
    # print() # Spacer
    # For loop that updates frequency table
    counter = 0
    for value in values:
        counter += 1
        h[value] += 1
    # print(h)

    # If statement that gives relative frequency
    if density==True:
        f = [] # Makes empty list
        f = h # Copies values list
        # print(f)

        # For loop iterating through f (copy of h)
        for i in range(len(f)):
            # For every value in f, divide by total
            f[i] = f[i]/counter

    # print(f)
    

    # Creates bars
    ax.bar(range(m+1), h, 1)
    # the x and y axis labels and title
    ax.set_ylabel(y_label)
    ax.set_xlabel(x_label)
    if len(title) > 0:
        ax.set_title(title)

    
    # print(x_label)

# Part 1 done
# fjbnm[spacebar][cmd] 

def part1(ax):
    # simulate tossing a 12 face die and make a probability mass function (PMF)

    values = []
    for i in range(0,101):
        die = random.randint(1,12)
        values.append(int(die))

    # print(values)
    hist(ax, values, x_label='Die' ,title='12 faced die outcomes', y_label='probability', density=True)



def part2(ax):
# explain the following lines of code reading data from a .dat file
# use your hist() function to plot the unbiased and biased distributions

    fin = open('2015_2017_MaleData.dat') #you may have to change the filepath
    numkdhh=[] # empty list
    biased_numkdhh=[] #empty list
    for line in fin: #iterate through every line of file
        v = int(line[3793]) # ints of number of children
        numkdhh.append(v) #add to unbiased list

        #create a vector for the biased distribution
        if v >= 1: # as long as there is one child
            for i in range(v): # for every child in household survey them
                biased_numkdhh.append(v) #add to biased list
        
    fin.close(); #close file
    

    # Unbiased Graph
    hist(ax, numkdhh, x_label="# of minors in household", y_label='Frequency', title="Unbiased")
    # Biased graph, sent to 1,1 space
    hist(axes[1,1], biased_numkdhh, x_label="# of minors in household", y_label='Frequency', title="Biased")





# #explain these lines of code focused on plotting
# #you may convert these to an "if name = main" statement like in Assignment 2

if __name__ == "__main__":
    # Makes the 2x2 bar graphs
    fig, axes = plt.subplots(2,2)
    plt.subplots_adjust(hspace=0.5) # Space between graphs

    part1(axes[0,0]) # Graph for part 1
    part2(axes[0,1]) # Graphs for part 2

    plt.show()

