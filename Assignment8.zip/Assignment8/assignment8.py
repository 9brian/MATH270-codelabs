## Math270 Assignment 8
## Brian Palomar
import math
import random
import matplotlib.pyplot as plt
#note that sin(x) is already a function math.sin()
#so we don't need to make a function for test1(x)

def test2(x): # return #1/3 (x^3) (write this in a way python understands)
    return ( pow(x,3) / 3) 

def test3(x): # return #sin(x)+1 (write this in a way python understands)
    return (math.sin(x) + 1)

def integrate(f, a, b, n):
    # f is function, a is start, b is boundary, ans boundary

    dx = (b-a)/n # derivative
    x = a # Copies a, to iterate to b
    value = 0 # holder for

    while x <= b:
        y = f(x) # f(x)
        #if x is the middle value, is not bound
        if(x != a) and (x != b): # if x is not starting, nor has reached the end
            value +=(2 * y) 
        else: # if x is bound, adds y value
            value += y
        #incrementing x by h(dx)
        x += dx
    #finding integrate of function
    value *= (dx/2)

    # s = (dx/2.0) * ( f(a) + 2.0*f(a+dx) + 2.0*f(a+2*dx) + f(b)) # Trapezoid rule
    return value # using trapezoid rule, program an integration function

def random3xsq():
    #create a function that generates random numbers from the
    #pdf function 3x^2. You'll need the cdf to do this!

    x = random.random()
    # return (3 * pow(x,2)) ??
    return pow(x, (1.0/3))


def hist(ax, values, x_label, 
            title='', y_label='Frequency', 
            density=False,
            bin_w=0, bin_start=0.0
            ):
    #start with last week's histogram function,
    #and add in the required binning parameters
    
    if bin_w > 0: # If bin values exist
        m = 0 # I&D max val
        for value in values: # For loop that updates max value
            if value > m:
                m = value # Max val updater

        x_axis = [0]*(int((m-bin_start)/bin_w)+1) # Creates x_axis
        for i in range(len(x_axis)): # Creates x_axis values
            x_axis[i] = (bin_start + i*bin_w)

            
        # nob = math.ceil( abs( ((m - bin_start) / bin_w ) + 1) ) # Creates number of bins
        nob = len(x_axis)# creates number of bins
       
        h = [0] * (nob) # initializes frequency table
        for value in values: # for loop to update frequency table
            h[int(value//bin_w)] += 1

        if density==True: # Gate to allow rf
            for index, frequency in enumerate(h): # iterate through frequency table
                h[index] = frequency / len(values) # Gives rf

        ax.bar(x_axis, h, width=bin_w, align='edge')
        ax.set_ylabel(y_label)  # the x and y axis labels and title
        ax.set_xlabel(x_label)
        if len(title) > 0:
            ax.set_title(title) # Sets table title
    
    
def runtest(f, a, b, correct):
    #Explain the steps given here
    n=1
    ans=0.0
    while (abs(ans-correct) > .01):
        n=n*2
        ans=integrate(f, a, b, n)
        print('n=%d ans=%.3f'%(n,ans))
# main program 
# part 1 
print("test1 f(x)=sin(x), 0,pi")
runtest(math.sin, 0, math.pi, 2.0)

print("test2 f(x)=1/3*x**3, from 1 to 4")
runtest(test2, 1, 4, 21.25)

print("test3 f(x)=sin(x)+1, from 0 to 2pi")
runtest(test3, 0, (2*math.pi), 6.283)
# part 2  generate 1 million random numbers and plot histogram
# Consider if this graph looks like 3x^2 before turning in
#     if it doesn't, make sure your random3xsq() function is ok
    #explain the steps used below
v=[]
for i in range(1000000):
    v.append(random3xsq())

fig, ax = plt.subplots()
hist(ax, v, 'x',
     title="random value from distribution with pdf(x)=3x**2",
     y_label="density",
     density=True,
     bin_w=.01,
     bin_start=0)
# display the chart
plt.show()