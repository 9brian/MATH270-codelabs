## Math270 Assignment 6
## Brian Palomar-Salazar
import matplotlib.pyplot as plt
import random
import math
# hist - make and display a frequency histogram
#        values - a list of integer values
#        binw_w - bin width
#        bin_start - lower bound of first bin
#        return - None
#
def hist(ax, values, x_label, 
            title='', y_label='Frequency', 
            density=False,
            bin_w=0, bin_start=0.0
            ):
    #start with last week's histogram function,
    #and add in the required binning parameters
    
    if bin_w == 0: # Default value, works as normal
        m = 0 # Initializes & declares
        for value in values: # For loop that updates max value
            if value > m:
                m = value

        h = [0] * (m+1) # Makes a list of 0's, acting as starting frequency table
        
        counter = 0
        for value in values: # For loop that updates frequency table
            counter += 1
            h[value] += 1

        if density==True: # If statement that gives relative frequency
            f = [] # Makes empty list
            f = h # Copies values list
            # print(f)

            for i in range(len(f)): # For loop iterating through f (copy of h)
                f[i] = f[i]/counter # For every value in f, divide by total

        ax.bar(range(m+1), h, 1) # Creates bars
        ax.set_ylabel(y_label)  # the x and y axis labels and title
        ax.set_xlabel(x_label)
        if len(title) > 0:
            ax.set_title(title) # Sets table title

    
    elif bin_w > 0: # If bin values exist
        # print("values := ", '\n', values, '\n')
        
        # number of bins is determined based on bin_start, bin_w, max_val
        # print("bin_w :=", bin_w)
        # print("bin_start :=", bin_start) # should i change bin_start?
        m = 0
        
        f=[]
        for value in values: # For loop that updates max value
            if value > m:
                m = value # Max val updater

            if value < 1: # if it is random between [0,1)]
                f.append(math.floor(value*10))
            else: # else
                f.append(math.floor(value))
        
        # print("Max_val in list as m :=", m)
        # print("f := ", f)
      
        if m < 1: # if max value is greater than 1
            # print("T", m)
            x_axis = [0] * (11) # initializes x_axis values
            for i in range(0,10): # for loop to create x_values
                x_axis[i] = (bin_start + i*bin_w) # Creates bin intervals
            # print("x_axis := ", x_axis, '\n')
            nob = math.ceil( abs( ((m - bin_start) / bin_w ) + 1) ) # Creates number of bins
        else:
            # print("F",m)
            x_axis = [0] * 14 # Initializes x_axis values
            for i in range(1,12): # for loop to update x_axis
                x_axis[i] = (bin_start + i*bin_w) # updater

            nob = len(x_axis) # creates number of bins

        # print("NumOfBins(nob) :=", nob)


        h = [0] * (nob) # initializes frequency table
        # print("h before := ", h, len(h))
        counter = 0 # counter 
        for value in f: # for loop to update frequency table
            counter += 1
            h[value] += 1
            # print(value)
        # print("h := ", h)

        if density==True: # If statement that gives relative frequency
            f = [] # Makes empty list
            f = h # Copies values list
            # print(f)

            for i in range(len(f)): # For loop iterating through f (copy of h)
                f[i] = f[i]/counter # For every value in f, divide by total
                # print(f[i],counter)
        # print(f)

        ax.bar(x_axis, h, width=bin_w, align='edge')
        ax.set_ylabel(y_label)  # the x and y axis labels and title
        ax.set_xlabel(x_label)
        if len(title) > 0:
            ax.set_title(title) # Sets table title

    
#     # print(x_label)

def avg(values): # avg calculator function
    #calculate the mean of the values (using the math package
            #we imported)
    
    # Checked the forum for mean value in math package,
    # Not sure how to do it?

    # Initialize & declare 
    num_of_nums = 0 # total num of values
    total = 0 # total values added up

    for value in values: # iterate through list passed in
        total = total + value # Update total tracker
        num_of_nums += 1 # Update num of values

    avg = (total / num_of_nums) # Calculates average
    
    return avg # Returns average

def std(values): #standard dev function
    #create a function that calculates standard deviation
    #hint: use the avg(values) function you just created

    mean = avg(values) # Mean of the values
    x_i = 0 # Holder for total
    for value in values: # Iterates through every value in list
        # Subtracts value[i] by mean, then squares it to find variance
            # before divided by n
        x_i += math.pow((value-mean),2) 
    
    # Finds standard deviation
    result = math.sqrt( x_i / len(values) )
    return result # returns result
   
 




#test your hist function using random.random()
def part1(ax):
    values = [ ]
    for i in range(100):
        values.append(random.random())
    # print("Part1 values: ",values)

    hist(ax, values, x_label='random value', y_label='Probability Density',
     density=True, bin_w=.1, bin_start=0.0,
     title='Random number avg= %.2f, std= %.2f'%(avg(values), std(values)))


def part2(ax):
# #complete the code below to 
    fin = open('Apr25_27thAn_set1.shtml') #you may need to change filepath
    paces = [ ] # paces in mph form
    t_time = [] # time in dec form
    for line in fin:
        minutes = "" # initializer
        seconds = "" # initializer
        dec_time = 0 # initializer
        
        # print(line)
        
        # line[38:40] # first two nums #line[38], line[39]
        # line[40:41] # Colon #line[40]
        # line[41:43] # Last two nums #line[41], line[42]

        #Enter code calculating mph here
        if (line[40:41] == ":"): #requirements for valid pace
            # print("T", line[38:40], line[41:43], line[40:41], " ", end="")
            
            if (line[38:40].isdigit() == True) and (line[41:43].isdigit() == True): #min is double digit
                # print(line[38],line[39], line[40],line[41], line[42], "A")
                minutes += line[38] # first min num
                minutes += line[39] # second min num
                seconds += line[41] # first sec num
                seconds += line[42] # second sec num
                dec_time = (0 * 60) + int(minutes) + (int(seconds) / 60) # dec time
                t_time.append(dec_time) # append to t_time
                paces.append(60/dec_time) # make it mph
                # print(minutes, line[40], seconds, " ", dec_time, " ")
            elif (line[39].isdigit() == True) and (line[41:43].isdigit() == True): # if min is single digit
                # print("0", line[39], line[40],line[41], line[42], "B")
                minutes += line[39] # first min num
                seconds += line[41] # first sec num
                seconds += line[42] # second sec num
                dec_time = (0 * 60) + int(minutes) + (int(seconds) / 60) # dec time
                t_time.append(dec_time) # append to t_time
                paces.append(60/dec_time) # make it mph
                # print(minutes, line[40], seconds, " ", dec_time, " ")
    # print("t_time := ", t_time)
    # print("paces := ", paces)
            
    fin.close()
    #as always, remember to explain the given python code!            
    print('number of racers ', len(paces)) # print num of racers
    print('slowest pace (mph) ',min(paces)) # print slowest pace
    print('fastest pace in (mph) ', max(paces)) # print fastest pace     
    hist(ax, paces, x_label='mph', bin_w=0.5 , bin_start=0.0,
         title='Racers speed avg=%.2f, std=%.2f'%(avg(paces),std(paces)),
         density=True, y_label='Probability Density')

if __name__ == "__main__":
    # Makes the 2x2 bar graphs
    fig, axes = plt.subplots(2,2, figsize=(10,5))
    plt.subplots_adjust(hspace=0.5) # Space between graphs

    part1(axes[0,0]) # Graph for part 1
    part2(axes[0,1]) # Graphs for part 2

    plt.show() # show graphs